// Clicking on cart will Alert--> "Your Cart is empty!"

function emptyCart(){
    alert("Your Cart is empty!");
}

// Hovering over the center img will change its src

function newImg(elem){
    elem.src="images/assets/succulents-2.jpg";
}

function oldImg(elem){
    elem.src="images/assets/succulents-1.jpg"
}

// Clicking "I Accept" will remove Cookie Bar

function removeElem(elem){
    elem.remove()
}

