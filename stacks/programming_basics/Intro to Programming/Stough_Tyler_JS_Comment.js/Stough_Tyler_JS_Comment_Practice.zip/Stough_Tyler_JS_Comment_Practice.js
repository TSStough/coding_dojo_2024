// Variable setting Like Count base line - what would this variable do?
var likeCount = 0;
// Input for a Like - what would be the function of this code block?
function increaseLikes() {
    // Whenever a Like is input increase likecount by 1 - what is this sort operation for?
    likeCount = likeCount + 1;
}
