// variables for minimum requirements to ride the roller coaster
var min_age = 10
var min_height = 42