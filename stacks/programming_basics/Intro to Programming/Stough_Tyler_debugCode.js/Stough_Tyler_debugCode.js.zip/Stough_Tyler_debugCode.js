/*Using what you know about functions, variables, console.log, and now returns, 
fix the following code so that it prints "Hello World" at the end.

function greeting(){
    return "Hello World";
}
var word = greeting();
console.log();
*/

function greeting(){
    return "Hello World";
}
var word = greeting();
console.log(word); //console.log () needed to be console.log(word) so that it new what to print out