I got a rainbow
and a spell checker